/* fonts */
export const FontFamily = {
  abhayaLibre: "Abhaya Libre",
  amstelvarAlpha: "AmstelvarAlpha",
  atkinsonHyperlegible: "Atkinson Hyperlegible",
};
/* font sizes */
export const FontSize = {
  size_sm: 10,
  size_base: 12,
  size_lg: 14,
  size_xl: 16,
};
/* Colors */
export const Color = {
  white: "#fff",
  black: "#000",
  indigo_100: "#6361dd",
  indigo_200: "#4946d7",
  indigo_300: "#2f2cd2",
  gray_100: "#d9d9d9",
  gray_200: "#757e74",
  green_100: "#107e06",
};
/* Margins */
export const Margin = {
  m_md: 0,
};
/* border radiuses */
export const Border = {
  br_md: 5,
};
